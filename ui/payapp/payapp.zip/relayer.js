

var myFormData = {
    key1: exchangeAddress,
    key2: makerAddress,
    key3: takerAddress,
    key4: senderAddress,
    key5: feeRecipientAddress,
    key6: expirationTimeSecond,
    key7: salt,
    key8: makerAssetAmount,
    key9: takerAssetAmount,
    key10: makerAssetData,
    key11: takerAssetData,
    key12: makerFee,
    key13: takerFee,
};

var fd = new FormData();
for (var key in myFormData) {
    console.log(key, myFormData[key]);
    fd.append(key, myFormData[key]);
}

function form (req, res) {
    console.log('form results: ' + req);
}